#ifndef DEFINES_H
#define DEFINES_H

// #define DEBUG_INFO_INTERFACES
// #define DEBUG_INFO_INTERFACES_BIND

#define WIDTH 200
#define HEIGHT 200


#endif // DEFINES_H
