#include <QApplication>
#include <QDebug>

#include "protocol/input-method-unstable-v1-client-protocol.h"
#include "protocol/text-input-unstable-v1-client-protocol.h"
#include "protocol/text-client-protocol.h"
#include "protocol/xdg-shell-client-protocol.h"
#include <linux/input-event-codes.h>

#include <wayland-client.h>
#include <sys/mman.h>
#include <sys/stat.h>        /* For mode constants */
#include <fcntl.h>           /* For O_* constants */
#include <unistd.h>
#include <wayland-egl.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <GL/gl.h>

#include "defines.h"

struct Client_state {
    struct wl_display       *display;
    struct wl_registry      *registry;
    struct wl_compositor    *compositor;
    struct wl_seat          *text_input_seat;
    struct wl_surface       *text_input_surface;
    struct wl_output        *output;
    struct wl_seat          *seat;
    struct wl_pointer       *pointer;

    struct zwp_text_input_manager_v1 *input_method_manager;
    struct zwp_input_method_v1 *input_method;
    struct zwp_text_input_v1 *text_input;

    struct zwp_input_method_context_v1 *context;
    struct wl_shm* shm = nullptr;

    struct wl_surface       *parent_surface;
    struct xdg_surface      *parent_xdg;

    char* surrounding_text;
    char *preedit_string;

    uint32_t content_purpose;

    struct xdg_wm_base  *xdg_wm_base;
    struct xdg_surface  *xdg_surface;
    struct xdg_popup    *xdg_popup;
    struct xdg_toplevel *xdg_toplevel;

    ///
    bool configured = false;
    ///
};

void check_gl(const char* msg) {
    GLenum err;
    while ((err = glGetError()) != GL_NO_ERROR) {
        printf("[OpenGL] %s: error code 0x%X\n", msg, err);
    }
}

EGLDisplay  egl_display;
EGLConfig   egl_config;
EGLContext  egl_context;
EGLSurface  egl_surface;

struct wl_egl_window *egl_window;

// ==================================================================================================================
// ==============================================   RENDER   ========================================================
// ==================================================================================================================

void render(Client_state *state)
{
    if (!eglMakeCurrent(egl_display, egl_surface, egl_surface, egl_context)) {
        qDebug() << "Failed to make EGL context current!";
        // return;
    }

    glViewport(0, 0, WIDTH, HEIGHT);
    check_gl("glViewport");

    glClearColor(0.0f, 0.5f, 0.8f, 0.5f);
    check_gl("glClearColor");

    glClear(GL_COLOR_BUFFER_BIT);
    check_gl("glClear");

    // glBegin(GL_QUADS);
    //     glVertex2f(-0.5f, -0.5f);
    //     glVertex2f(0.5f, -0.5f);
    //     glVertex2f(0.5f, 0.5f);
    //     glVertex2f(-0.5f, 0.5f);
    // glEnd();

    if (eglSwapBuffers(egl_display, egl_surface) == EGL_FALSE){
        qDebug() << "SwapBuffers failed!";
    }
    check_gl("eglSwapBuffers");
    wl_surface_commit(state->parent_surface);
}

void clear_keyboard(Client_state* state)
{
    if (!eglMakeCurrent(egl_display, egl_surface, egl_surface, egl_context)) {
        qDebug() << "Failed to make EGL context current!";
        // return;
    }

    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    check_gl("egClear");
    if (eglSwapBuffers(egl_display, egl_surface) == EGL_FALSE){
        qDebug() << "SwapBuffers failed!";
    }
    check_gl("eglSwapBuffers");
    wl_surface_commit(state->text_input_surface);
}

// ====================================================================================================================

static void pointer_enter(void *data,
                          struct wl_pointer *wl_pointer,
                          uint32_t serial,
                          struct wl_surface *surface,
                          wl_fixed_t surface_x,
                          wl_fixed_t surface_y){

}

static void pointer_leave(void *data,
                          struct wl_pointer *wl_pointer,
                          uint32_t serial,
                          struct wl_surface *surface){

}

static void pointer_motion(void *data,
                           struct wl_pointer *wl_pointer,
                           uint32_t time,
                           wl_fixed_t surface_x,
                           wl_fixed_t surface_y){

}

static void pointer_button(void *data,
                           struct wl_pointer *wl_pointer,
                           uint32_t serial,
                           uint32_t time,
                           uint32_t button,
                           uint32_t state){
    if (button == BTN_LEFT && state == WL_POINTER_BUTTON_STATE_PRESSED){
        qDebug() << "Pressed";
    }
}

const static wl_pointer_listener pointer_listener = {
    pointer_enter,
    pointer_leave,
    pointer_motion,
    pointer_button
};

static void
zwp_input_method_context_surrounding_text(void *data,
                                          struct zwp_input_method_context_v1 *context,
                                          const char *text,
                                          uint32_t cursor,
                                          uint32_t anchor)
{

}

static void
zwp_input_method_context_reset(void *data,
                               struct zwp_input_method_context_v1 *context)
{
}

static void
zwp_input_method_context_content_type(void *data,
                                      struct zwp_input_method_context_v1 *context,
                                      uint32_t hint,
                                      uint32_t purpose)
{

}

static void
zwp_input_method_context_invoke_action(void *data,
                                       struct zwp_input_method_context_v1 *context,
                                       uint32_t button,
                                       uint32_t index)
{

}

static void
zwp_input_method_context_commit_state(void *data,
                                      struct zwp_input_method_context_v1 *context,
                                      uint32_t serial)
{

    struct Client_state *keyboard = ( struct Client_state *)data;
    qDebug() << "ZWP surrounding text updated: " << keyboard->surrounding_text;

}

static void
zwp_input_method_context_preferred_language(void *data,
                                            struct zwp_input_method_context_v1 *zwp_input_method_context_v1,
                                            const char *language)
{

}

static const struct zwp_input_method_context_v1_listener context_listener = {
    zwp_input_method_context_surrounding_text,
    zwp_input_method_context_reset,
    zwp_input_method_context_content_type,
    zwp_input_method_context_invoke_action,
    zwp_input_method_context_commit_state,
    zwp_input_method_context_preferred_language
};

static void xdg_surface_configure(void *data, struct xdg_surface *surface, uint32_t serial) {
    xdg_surface_ack_configure(surface, serial);
    Client_state* state = static_cast<Client_state*>(data);
    state->configured = true;
    qDebug() << "Configured";
}

static const struct xdg_surface_listener xdg_surface_listener = {
    .configure = xdg_surface_configure
};

void create_popup(Client_state* state)
{
    state->text_input_surface = wl_compositor_create_surface(state->compositor);
    state->xdg_surface = xdg_wm_base_get_xdg_surface(state->xdg_wm_base, state->text_input_surface);
    xdg_surface_add_listener(state->xdg_surface, &xdg_surface_listener, state);

    // Parent surface
    state->parent_surface = wl_compositor_create_surface(state->compositor);
    state->parent_xdg = xdg_wm_base_get_xdg_surface(state->xdg_wm_base, state->parent_surface);
    xdg_surface_add_listener(state->parent_xdg, &xdg_surface_listener, state);

    state->xdg_toplevel = xdg_surface_get_toplevel(state->parent_xdg);
    xdg_toplevel_set_title(state->xdg_toplevel, "Parent Window");
    xdg_toplevel_set_app_id(state->xdg_toplevel, "org.example.parent");
    wl_surface_commit(state->parent_surface);

    struct xdg_positioner *positioner = xdg_wm_base_create_positioner(state->xdg_wm_base);
    xdg_positioner_set_anchor(positioner, XDG_POSITIONER_ANCHOR_BOTTOM_LEFT);
    xdg_positioner_set_gravity(positioner, XDG_POSITIONER_GRAVITY_TOP_LEFT);
    xdg_positioner_set_size(positioner, WIDTH, HEIGHT);
    xdg_positioner_set_anchor_rect(positioner, 0, 0, 1, 1);
    xdg_positioner_set_constraint_adjustment(positioner, XDG_POSITIONER_CONSTRAINT_ADJUSTMENT_NONE);

    state->xdg_popup = xdg_surface_get_popup(state->xdg_surface, state->parent_xdg, positioner);
    xdg_positioner_destroy(positioner);

    wl_surface_commit(state->text_input_surface);
    wl_display_roundtrip(state->display);
}

void create_toplevel(Client_state* state)
{
    state->text_input_surface = wl_compositor_create_surface(state->compositor);
    state->xdg_surface = xdg_wm_base_get_xdg_surface(state->xdg_wm_base, state->text_input_surface);
    xdg_surface_add_listener(state->xdg_surface, &xdg_surface_listener, state);

    state->xdg_toplevel = xdg_surface_get_toplevel(state->xdg_surface);
    xdg_toplevel_set_title(state->xdg_toplevel, "Input Method");
    xdg_toplevel_set_app_id(state->xdg_toplevel, "org.example.inputmethod");

    struct wl_region *input_region = wl_compositor_create_region(state->compositor);
    wl_surface_set_input_region(state->text_input_surface, input_region);
    wl_region_destroy(input_region);

    wl_surface_commit(state->text_input_surface);
    wl_display_roundtrip(state->display);
    qDebug() << "Top level created";
}

void create_egl_surface(Client_state *state)
{
    if (!state->text_input_surface){
        qDebug() << "Text input surface not created";
        // return;
    }
    egl_window = wl_egl_window_create(state->text_input_surface, WIDTH, HEIGHT);
    if (!egl_window) {
        qDebug() << "Failed to create wl_egl_window!";
        // return;
    }
    egl_surface = eglCreateWindowSurface(egl_display, egl_config, (EGLNativeWindowType)egl_window, nullptr);
    if (egl_surface == EGL_NO_SURFACE){
        qDebug() << "Failed to create EGL surface!";
        // return;
    }
    if (!eglMakeCurrent(egl_display, egl_surface, egl_surface, egl_context)) {
        qDebug() << "Failed to make EGL context current!";
        // return;
    }
}

static void input_method_activate(void *data,
                                  struct zwp_input_method_v1 *zwp_input_method_v1,
                                  struct zwp_input_method_context_v1 *id){
    qDebug() << "Input method activated";

    auto state = (Client_state *) data;

    wl_pointer_add_listener(state->pointer, &pointer_listener, state);

    if (!state->text_input_surface) {
        create_toplevel(state);
        create_egl_surface(state);
        qDebug() << "Created wl_surface: " << state->text_input_surface;
        qDebug() << "Created xdg_surface: " << state->text_input_surface;
    }
    // Create surface
    // if (!state->text_input_surface) {
    //     // create_xdg_surface(keyboard);
    //     qDebug() << "Created wl_surface: " << state->text_input_surface;
    //     qDebug() << "Created xdg_surface: " << state->text_input_surface;
    //     // create_egl_surface(keyboard);
    // }
    wl_surface_commit(state->text_input_surface);
    render(state);
    wl_surface_commit(state->text_input_surface);
}

static void input_method_deactivate(void *data,
                                    struct zwp_input_method_v1 *zwp_input_method_v1,
                                    struct zwp_input_method_context_v1 *context){
    qDebug() << "Input method deactivated";
    clear_keyboard((Client_state*) data);
    qDebug() << "Keyboard cleared";
}

static const struct zwp_input_method_v1_listener input_method_listener = {
    .activate = input_method_activate,
    .deactivate = input_method_deactivate
};

static void registry_global(void *data,
                            struct wl_registry *wl_registry,
                            uint32_t name,
                            const char *interface,
                            uint32_t version) {
    auto state = (Client_state*) data;

// Current interface name
#ifdef DEBUG_INFO_INTERFACES
    qDebug() << interface;
#endif
    if (strcmp(interface, wl_compositor_interface.name) == 0){
        state->compositor = (wl_compositor*) wl_registry_bind(state->registry, name, &wl_compositor_interface, 4);
#ifdef DEBUG_INFO_INTERFACES_BIND
        qDebug() <<  wl_compositor_interface.name << "BINDED!";
#endif
    }
    if (strcmp(interface, wl_shm_interface.name) == 0){
        state->shm = (wl_shm*) wl_registry_bind(state->registry, name, &wl_shm_interface, 1);
#ifdef DEBUG_INFO_INTERFACES_BIND
        qDebug() << wl_shm_interface.name << "BINDED!";
#endif
    }
    if (strcmp(interface, zwp_text_input_manager_v1_interface.name) == 0){
        state->input_method_manager = (zwp_text_input_manager_v1*) wl_registry_bind(state->registry, name, &zwp_text_input_manager_v1_interface, 1);
#ifdef DEBUG_INFO_INTERFACES_BIND
        qDebug() << zwp_text_input_manager_v1_interface.name << "BINDED!";
#endif
    }
    if (strcmp(interface, zwp_input_method_v1_interface.name) == 0){
        state->input_method = (zwp_input_method_v1*) wl_registry_bind(state->registry, name, &zwp_input_method_v1_interface, 1);
#ifdef DEBUG_INFO_INTERFACES_BIND
        qDebug() << zwp_input_method_v1_interface.name << "BINDED!";
#endif
        zwp_input_method_v1_add_listener(state->input_method, &input_method_listener, state);
    }
    if (strcmp(interface, xdg_wm_base_interface.name) == 0) {
        state->xdg_wm_base = (xdg_wm_base*) wl_registry_bind(wl_registry, name, &xdg_wm_base_interface, 2);
#ifdef DEBUG_INFO_INTERFACES_BIND
        qDebug() << xdg_wm_base_interface.name << " BINDED!";
#endif
    }
    if (strcmp(interface, wl_output_interface.name) == 0) {
        state->output = (wl_output*) wl_registry_bind(wl_registry, name, &wl_output_interface, 1);
#ifdef DEBUG_INFO_INTERFACES_BIND
        qDebug() << wl_output_interface.name << " BINDED!";
#endif
    }
    if (strcmp(interface, wl_seat_interface.name) == 0)
    {
        state->seat = (wl_seat*) wl_registry_bind(wl_registry, name, &wl_seat_interface, 1);
        state->pointer = wl_seat_get_pointer(state->seat);
#ifdef DEBUG_INFO_INTERFACES_BIND
        qDebug() << wl_seat_interface.name << " BINDED!";
#endif
    }

}

static void registry_remove(void *data,
                            struct wl_registry *wl_registry,
                            uint32_t name) {

}

static const struct wl_registry_listener Registry_listener {
    .global = registry_global,
    .global_remove = registry_remove
};

void init_egl(Client_state* state)
{
    egl_display = eglGetDisplay((EGLNativeDisplayType)state->display);
    EGLint major, minor;
    if(!eglInitialize(egl_display, &major, &minor)){
        qDebug() << "Failed to initialize EGL";
    }
    qDebug() << "EGL initialized version: " << major << "." << minor;

    static const EGLint config_attributes[] = {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RED_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_BLUE_SIZE, 8,
        EGL_ALPHA_SIZE, 8,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
        EGL_NONE
    };
    EGLint num_configs;
    eglChooseConfig(egl_display, config_attributes, &egl_config, 1, &num_configs);

    static const EGLint context_attributes[] = {
        EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE
    };

    egl_context = eglCreateContext(egl_display, egl_config, EGL_NO_CONTEXT, context_attributes);
    if (egl_context == EGL_NO_CONTEXT) {
        qDebug() << "Failed to create EGL context";
    }
}

void init_wayland(Client_state* state)
{
    state->display = wl_display_connect(nullptr);

    state->registry = wl_display_get_registry(state->display);
    wl_registry_add_listener(state->registry, &Registry_listener, state);
    wl_display_roundtrip(state->display);
}

void destroy_wayland(Client_state* state)
{
    if (state->xdg_toplevel)xdg_toplevel_destroy(state->xdg_toplevel);
    if (state->xdg_surface) xdg_surface_destroy(state->xdg_surface);
    if (state->xdg_wm_base) xdg_wm_base_destroy(state->xdg_wm_base);
    // etc
}

int main(int argc, char **argv)
{
    auto state = new Client_state();

    init_wayland(state);
    init_egl(state);

    while (wl_display_dispatch(state->display) != -1){
    }

    wl_display_disconnect(state->display);

    destroy_wayland(state);

    return 0;
}
