#include <QApplication>
#include <QDebug>

#include "protocol/input-method-unstable-v1-client-protocol.h"
#include "protocol/text-input-unstable-v1-client-protocol.h"
#include "protocol/text-client-protocol.h"
#include "protocol/xdg-shell-client-protocol.h"

#include <wayland-client.h>
#include <sys/mman.h>
#include <sys/stat.h>        /* For mode constants */
#include <fcntl.h>           /* For O_* constants */
#include <unistd.h>
#include <wayland-egl.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>

struct Client_state {
    struct wl_display *display;
    struct wl_registry *registry;
    struct wl_compositor *compositor;
    struct wl_seat *text_input_seat;
    struct wl_surface *text_input_surface;

    struct zwp_text_input_manager_v1 *input_method_manager;
    struct zwp_input_method_v1 *input_method;
    struct zwp_text_input_v1 *text_input;

    struct zwp_input_method_context_v1 *context;
    struct wl_shm* shm = nullptr;

    char* surrounding_text;
    char *preedit_string;

    uint32_t content_purpose;

    struct xdg_wm_base *xdg_wm_base;
    struct xdg_surface *xdg_surface;
    struct xdg_toplevel *xdg_toplevel;
};

void check_gl(const char* msg) {
    GLenum err;
    while ((err = glGetError()) != GL_NO_ERROR) {
        printf("[OpenGL] %s: error code 0x%X\n", msg, err);
    }
}

enum key_type {
    keytype_default,
    keytype_backspace,
    keytype_enter,
    keytype_space,
    keytype_switch,
    keytype_symbols,
    keytype_tab,
    keytype_arrow_up,
    keytype_arrow_left,
    keytype_arrow_right,
    keytype_arrow_down,
    keytype_style
};

struct key {
    enum key_type key_type;

    char *label;
    char *alt;

    unsigned int width;
};

int width = 100;
int height = 100;
int shm_fd;
void* shm_data;
wl_buffer* buffer = nullptr;
wl_shm_pool* shm_pool = nullptr;

EGLDisplay  egl_display;
EGLConfig   egl_config;
EGLContext  egl_context;
EGLSurface  egl_surface;

struct wl_egl_window *egl_window;


void render(Client_state *state)
{
    glViewport(0, 0, width, height);
    check_gl("glViewport");

    glClearColor(0.0f, 0.5f, 0.8f, 0.5f);  // Яркий синий цвет для видимости
    check_gl("glClearColor");

    glClear(GL_COLOR_BUFFER_BIT);
    check_gl("glClear");

    eglSwapBuffers(egl_display, egl_surface);
    check_gl("eglSwapBuffers");

    wl_surface_damage(state->text_input_surface, 0, 0, width, height);
    wl_surface_commit(state->text_input_surface);
}

void clear_keyboard(Client_state* state)
{
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    eglSwapBuffers(egl_display, egl_surface);
    wl_surface_commit(state->text_input_surface);
}

static void
zwp_input_method_context_surrounding_text(void *data,
                                          struct zwp_input_method_context_v1 *context,
                                          const char *text,
                                          uint32_t cursor,
                                          uint32_t anchor)
{

}

static void
zwp_input_method_context_reset(void *data,
                               struct zwp_input_method_context_v1 *context)
{
}

static void
zwp_input_method_context_content_type(void *data,
                                      struct zwp_input_method_context_v1 *context,
                                      uint32_t hint,
                                      uint32_t purpose)
{

}

static void
zwp_input_method_context_invoke_action(void *data,
                                       struct zwp_input_method_context_v1 *context,
                                       uint32_t button,
                                       uint32_t index)
{

}

static void
zwp_input_method_context_commit_state(void *data,
                                      struct zwp_input_method_context_v1 *context,
                                      uint32_t serial)
{

    struct Client_state *keyboard = ( struct Client_state *)data;
    qDebug() << "ZWP surrounding text updated: " << keyboard->surrounding_text;

}

static void
zwp_input_method_context_preferred_language(void *data,
                                            struct zwp_input_method_context_v1 *zwp_input_method_context_v1,
                                            const char *language)
{

}


static const struct zwp_input_method_context_v1_listener context_listener = {
    zwp_input_method_context_surrounding_text,
    zwp_input_method_context_reset,
    zwp_input_method_context_content_type,
    zwp_input_method_context_invoke_action,
    zwp_input_method_context_commit_state,
    zwp_input_method_context_preferred_language
};


void
keysym_modifiers_add(struct wl_array *modifiers_map,
                     const char *name)
{
    size_t len = strlen(name) + 1;
    char *p;

    p = (char*)wl_array_add(modifiers_map, len);

    if (p == NULL)
        return;

    strncpy(p, name, len);
}

static void xdg_surface_configure(void *data, struct xdg_surface *surface, uint32_t serial) {
    xdg_surface_ack_configure(surface, serial);

    Client_state* state = static_cast<Client_state*>(data);
    render(state);
}

static const struct xdg_surface_listener xdg_surface_listener = {
    .configure = xdg_surface_configure
};

// Обновим create_xdg_surface
void create_xdg_surface(Client_state* state) {
    state->xdg_surface = xdg_wm_base_get_xdg_surface(state->xdg_wm_base, state->text_input_surface);
    xdg_surface_add_listener(state->xdg_surface, &xdg_surface_listener, state);

    state->xdg_toplevel = xdg_surface_get_toplevel(state->xdg_surface);
    xdg_toplevel_set_title(state->xdg_toplevel, "Input Method");
    xdg_toplevel_set_app_id(state->xdg_toplevel, "org.example.inputmethod");

    // Обязательно делаем commit для инициализации
    wl_surface_commit(state->text_input_surface);
    wl_display_roundtrip(state->display);
}

static void input_method_activate(void *data,
                                  struct zwp_input_method_v1 *zwp_input_method_v1,
                                  struct zwp_input_method_context_v1 *id){
    qDebug() << "input method activated";

    auto keyboard = (Client_state *) data;

    // Создаем wl_surface (если еще не создана)
    if (!keyboard->text_input_surface) {
        keyboard->text_input_surface = wl_compositor_create_surface(keyboard->compositor);
        create_xdg_surface(keyboard);
    }
    wl_surface_damage(keyboard->text_input_surface, 0, 0, width, height);
    wl_surface_commit(keyboard->text_input_surface);
    wl_display_roundtrip(keyboard->display);
    // zwp_input_method_context_v1_set_surface(id, keyboard->text_input_surface);

    printf("Created wl_surface: %p\n", keyboard->text_input_surface);
    wl_surface_attach(keyboard->text_input_surface, buffer, 0, 0);
    wl_surface_commit(keyboard->text_input_surface);
    wl_display_roundtrip(keyboard->display);
    egl_window = wl_egl_window_create(keyboard->text_input_surface, width, height);
    if (!egl_window) {
        printf("Failed to create wl_egl_window!\n");
    }
    egl_surface = eglCreateWindowSurface(egl_display, egl_config, (EGLNativeWindowType)egl_window, nullptr);
    eglMakeCurrent(egl_display, egl_surface, egl_surface, egl_context);
    wl_surface_commit(keyboard->text_input_surface);
    render(keyboard);
    // wl_surface_commit(text_input_surface);
    qDebug() << "otrisovano";
}

static void input_method_deactivate(void *data,
                                    struct zwp_input_method_v1 *zwp_input_method_v1,
                                    struct zwp_input_method_context_v1 *context){
    qDebug() << "Input method deactivated";
    clear_keyboard((Client_state*) data);
}

static const struct zwp_input_method_v1_listener input_method_listener = {
    .activate = input_method_activate,
    .deactivate = input_method_deactivate
};

static void registry_global(void *data,
                            struct wl_registry *wl_registry,
                            uint32_t name,
                            const char *interface,
                            uint32_t version) {
    auto state = (Client_state*) data;
    qDebug() << interface;
    if (strcmp(interface, wl_compositor_interface.name) == 0){
        state->compositor = (wl_compositor*) wl_registry_bind(state->registry, name, &wl_compositor_interface, 4);
        qDebug() << "Compositor binded!";
    }
    if (strcmp(interface, wl_shm_interface.name) == 0){
        state->shm = (wl_shm*) wl_registry_bind(state->registry, name, &wl_shm_interface, 1);
        qDebug() << "Shm binded!";
    }
    if (strcmp(interface, zwp_text_input_manager_v1_interface.name) == 0){
        state->input_method_manager = (zwp_text_input_manager_v1*) wl_registry_bind(state->registry, name, &zwp_text_input_manager_v1_interface, 1);
        qDebug() << "Input_method_manager binded!";
    }
    if (strcmp(interface, zwp_input_method_v1_interface.name) == 0){
        state->input_method = (zwp_input_method_v1*) wl_registry_bind(state->registry, name, &zwp_input_method_v1_interface, 1);
        qDebug() << "Input_method binded!";
        zwp_input_method_v1_add_listener(state->input_method, &input_method_listener, state);
    }
    if (strcmp(interface, xdg_wm_base_interface.name) == 0) {
        state->xdg_wm_base = (xdg_wm_base*)wl_registry_bind(wl_registry, name, &xdg_wm_base_interface, 2);
    }

}

static void registry_remove(void *data,
                            struct wl_registry *wl_registry,
                            uint32_t name) {

}

static const struct wl_registry_listener Registry_listener {
    .global = registry_global,
    .global_remove = registry_remove
};

int allocate_shm_file(int size) {
    char filename[] = "/home/artem/workProjects/wayland-shm-XXXXXX";
    int fd = mkstemp(filename); ///< file descritptor
    unlink(filename);
    ftruncate(fd, size);
    return fd;
}

void init_egl(Client_state* state)
{
    egl_display = eglGetDisplay((EGLNativeDisplayType)state->display);
    eglInitialize(egl_display, nullptr, nullptr);

    static const EGLint config_attributes[] = {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RED_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_BLUE_SIZE, 8,
        EGL_ALPHA_SIZE, 8,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
        EGL_NONE
    };
    EGLint num_configs;
    eglChooseConfig(egl_display, config_attributes, &egl_config, 1, &num_configs);

    static const EGLint context_attributes[] = {
        EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE
    };

    egl_context = eglCreateContext(egl_display, egl_config, EGL_NO_CONTEXT, context_attributes);
}

void init_surface(Client_state* state)
{
    state->text_input_surface = wl_compositor_create_surface(state->compositor);
    egl_window = wl_egl_window_create(state->text_input_surface, width, height);
    egl_surface = eglCreateWindowSurface(egl_display, egl_config, (EGLNativeWindowType)egl_window, nullptr);
    eglMakeCurrent(egl_display, egl_surface, egl_surface, egl_context);
}


void init_wayland(Client_state* state)
{
    state->display = wl_display_connect(nullptr);

    state->registry = wl_display_get_registry(state->display);
    wl_registry_add_listener(state->registry, &Registry_listener, state);
    wl_display_roundtrip(state->display);
}

int main(int argc, char **argv)
{
    auto state = new Client_state();

    init_wayland(state);
    init_egl(state);

    while (wl_display_dispatch(state->display) != -1){
    }

    if (state->xdg_toplevel)xdg_toplevel_destroy(state->xdg_toplevel);
    if (state->xdg_surface) xdg_surface_destroy(state->xdg_surface);
    if (state->xdg_wm_base) xdg_wm_base_destroy(state->xdg_wm_base);

    wl_display_disconnect(state->display);
    // delete state;

    return 0;
}
